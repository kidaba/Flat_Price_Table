<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Strict//EN">

<html class="contact-background">
<head>
	<title>Message sent to Inspired Web</title>
	
	<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<link href="css/font-awesome.min.css" rel="stylesheet" type="text/css" media="all" />
<!-- Custom Theme files -->
<link href='http://fonts.googleapis.com/css?family=Lora:400,700' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Oswald:400,300,700' rel='stylesheet' type='text/css'>
<link href="css/style.css" rel='stylesheet' type='text/css' />	

</head>

<body class="contact-background">


	<div class="container">
	<div class="logo center-block">
			
				<img src="images/inspiredsmall.png" alt="logo" class="img-responsive">
				
			</div> 
			
			
	<div id="page-wrap">
	

		
			
		<h1 class="contact-font">Thank you for your message, we will contact you shortly.</h1><br />
		
		
		
		<div class="button">
				<input type="submit" value="Close" onclick="location.href='http://www.inspiredweb.co.za'">
		</div>
		
	</div>
	
</div>
	
</body>

</html>